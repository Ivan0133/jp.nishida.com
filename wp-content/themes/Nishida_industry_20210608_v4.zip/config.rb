css_dir = "./assets/css"
sass_dir = "./assets/scss"
images_dir = "./assets/img"
relative_assets = true

output_style = :compact
line_comments = false

preferred_syntax = :scss

sourcemap=true